--ハーピィ・レディ三姉妹
---@param c Card
function c12206212.initial_effect(c)
	c:EnableReviveLimit()
end
